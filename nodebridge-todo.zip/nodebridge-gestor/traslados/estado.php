<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/traslados.php';

$u = requerir_login();
exigir_post_con_csrf();
$admin = es_admin();
$pdo = db();

$id = (int) ($_POST['id'] ?? 0);
$accion = (string) ($_POST['accion'] ?? '');

$st = $pdo->prepare('SELECT id_traslado, estado, id_solicitante, id_ambulancia FROM traslado WHERE id_traslado = ?');
$st->execute([$id]);
$t = $st->fetch();

if (!$t) {
    avisar('El traslado no existe.', 'danger');
} elseif (!$admin && (int) $t['id_solicitante'] !== (int) $u['id_funcionario']) {
    avisar('Solo puede modificar sus propias solicitudes.', 'danger');
} elseif ($accion === 'cambiar') {
    $nuevo = (string) ($_POST['estado'] ?? '');
    if (!isset(SEGUIMIENTO_TRASLADO[$nuevo]) || !isset(SEGUIMIENTO_TRASLADO[$t['estado']]) || $t['id_ambulancia'] === null) {
        avisar('Este traslado no se puede pasar a ese estado.', 'warning');
    } elseif ($nuevo === $t['estado']) {
        avisar('El traslado ya estaba en ese estado.', 'info');
    } else {
        $idAmb = (int) $t['id_ambulancia'];
        $activos = ESTADOS_TRASLADO_ACTIVOS;
        $marcas = implode(',', array_fill(0, count($activos), '?'));
        $motivoRechazo = '';

        if (SEGUIMIENTO_TRASLADO[$nuevo] !== 'disponible' || $nuevo === 'asignado') {
            $q = $pdo->prepare("SELECT 1 FROM traslado WHERE id_ambulancia = ? AND id_traslado <> ? AND estado IN ($marcas) LIMIT 1");
            $q->execute(array_merge([$idAmb, $id], $activos));
            if ($q->fetchColumn()) {
                $motivoRechazo = 'La ambulancia ya está asignada a otro traslado en curso.';
            }
            $q = $pdo->prepare('SELECT estado FROM ambulancia WHERE id_ambulancia = ?');
            $q->execute([$idAmb]);
            if ($t['estado'] === 'finalizado' && $q->fetchColumn() === 'fuera_servicio') {
                $motivoRechazo = 'La ambulancia está fuera de servicio.';
            }
        }

        if ($motivoRechazo !== '') {
            avisar('No se pudo reabrir el traslado: ' . $motivoRechazo, 'warning');
        } else {
            $pdo->beginTransaction();

            $r = $pdo->prepare('UPDATE traslado SET estado = ? WHERE id_traslado = ? AND estado = ?');
            $r->execute([$nuevo, $id, $t['estado']]);
            if ($r->rowCount() > 0) {
                $pdo->prepare('UPDATE ambulancia SET estado = ?, fecha_estado = ? WHERE id_ambulancia = ?')
                    ->execute([SEGUIMIENTO_TRASLADO[$nuevo], date('Y-m-d H:i:s'), $idAmb]);
                $pdo->commit();
                avisar('Estado actualizado: ' . ESTADOS_TRASLADO[$nuevo][0] . '.');
            } else {
                $pdo->rollBack();
                avisar('El traslado ya había cambiado de estado. Revise la lista.', 'warning');
            }
        }
    }
} elseif ($accion === 'desasignar') {
    if (!$admin || $t['estado'] !== 'asignado') {
        avisar('Solo un administrador puede quitar la ambulancia de un traslado que todavía no salió.', 'warning');
    } else {
        $r = $pdo->prepare("UPDATE traslado SET estado = 'pendiente', id_ambulancia = NULL, fecha_asignacion = NULL WHERE id_traslado = ? AND estado = 'asignado'");
        $r->execute([$id]);
        avisar($r->rowCount() > 0 ? 'Se quitó la ambulancia: la solicitud volvió a pendiente.' : 'El traslado ya había cambiado de estado.', $r->rowCount() > 0 ? 'success' : 'warning');
    }
} elseif ($accion === 'cancelar') {
    $permitido = $t['estado'] === 'pendiente' || ($t['estado'] === 'asignado' && $admin);
    if (!$permitido) {
        avisar('Esta solicitud ya no se puede cancelar.', 'warning');
    } else {
        $r = $pdo->prepare("UPDATE traslado SET estado = 'cancelado' WHERE id_traslado = ? AND estado = ?");
        $r->execute([$id, $t['estado']]);
        avisar($r->rowCount() > 0 ? 'Solicitud cancelada.' : 'El traslado ya había cambiado de estado.', $r->rowCount() > 0 ? 'success' : 'warning');
    }
} else {
    avisar('Acción inválida.', 'danger');
}
redirigir('traslados/index.php');
