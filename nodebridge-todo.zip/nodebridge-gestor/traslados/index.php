<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/traslados.php';

$u = requerir_login();
$pdo = db();
$admin = es_admin();

$q = trim((string) ($_GET['q'] ?? ''));
$estadoSel = (string) ($_GET['estado'] ?? '');

$donde = [];
$params = [];
if (!$admin) {
    $donde[] = 't.id_solicitante = ?';
    $params[] = (int) $u['id_funcionario'];
}
if ($q !== '') {
    $digitos = preg_replace('/\D/', '', $q) ?? '';
    $donde[] = '(t.nombre_paciente LIKE ?' . ($digitos !== '' ? ' OR t.cedula_paciente LIKE ?' : '') . ')';
    $params[] = '%' . addcslashes($q, '%_\\') . '%';
    if ($digitos !== '') {
        $params[] = '%' . $digitos . '%';
    }
}
if (isset(ESTADOS_TRASLADO[$estadoSel])) {
    $donde[] = 't.estado = ?';
    $params[] = $estadoSel;
}
$sqlDonde = $donde ? 'WHERE ' . implode(' AND ', $donde) : '';

$st = $pdo->prepare("SELECT COUNT(*) FROM traslado t $sqlDonde");
$st->execute($params);
$total = (int) $st->fetchColumn();
[$pagina, $paginas, $desde] = paginar($total, 15);

$st = $pdo->prepare(
    "SELECT t.*, f.nombre AS solicitante, a.nombre AS ambulancia, a.matricula, c.nombre_completo AS conductor
       FROM traslado t
       JOIN funcionario f ON f.id_funcionario = t.id_solicitante
       LEFT JOIN ambulancia a ON a.id_ambulancia = t.id_ambulancia
       LEFT JOIN conductor c ON c.id_conductor = a.id_conductor
       $sqlDonde
      ORDER BY CASE WHEN t.estado = 'pendiente' THEN 0 ELSE 1 END, t.fecha_salida DESC, t.id_traslado DESC
      LIMIT 15 OFFSET $desde"
);
$st->execute($params);
$traslados = $st->fetchAll();
$hayFiltros = $q !== '' || isset(ESTADOS_TRASLADO[$estadoSel]);

encabezado('Traslados', 'traslados');
?>
<p class="text-secondary">
    <?= $admin
        ? 'Solicitudes de traslado de todos los funcionarios. Las pendientes aparecen primero: asigne una ambulancia o recházelas.'
        : 'Acá ve sus solicitudes de traslado. El administrador asigna la ambulancia; después toque el estado para ir marcando el recorrido (se puede volver atrás si se equivoca).' ?>
</p>

<div class="d-flex flex-wrap gap-2 justify-content-between align-items-start mb-3">
    <form method="GET" class="row g-2 flex-grow-1" style="max-width: 760px;">
        <div class="col-12 col-md-5">
            <input type="search" class="form-control" name="q" placeholder="Buscar por paciente o cédula..." value="<?= h($q) ?>" aria-label="Buscar por paciente o cédula">
        </div>
        <div class="col-8 col-md-4">
            <select class="form-select" name="estado" aria-label="Estado">
                <option value="">Todos los estados</option>
                <?php foreach (ESTADOS_TRASLADO as $clave => [$texto]): ?>
                    <option value="<?= h($clave) ?>"<?= $estadoSel === $clave ? ' selected' : '' ?>><?= h($texto) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-4 col-md-2 d-grid"><button class="btn btn-primary" type="submit">Buscar</button></div>
        <?php if ($hayFiltros): ?>
            <div class="col-12 col-md-1 d-grid"><a class="btn btn-outline-secondary" href="<?= h(url('traslados/index.php')) ?>">Limpiar</a></div>
        <?php endif; ?>
    </form>
    <div class="d-flex flex-wrap gap-2">
        <?php if ($admin): ?>
            <a class="btn btn-outline-secondary" href="<?= h(url('traslados/ambulancias.php')) ?>">Ambulancias</a>
        <?php endif; ?>
        <a class="btn btn-success" href="<?= h(url('traslados/formulario.php')) ?>">Solicitar traslado</a>
    </div>
</div>

<div class="card">
    <?php if (!$traslados): ?>
        <div class="card-body text-secondary">
            <?= $hayFiltros ? 'No se encontraron traslados con esa búsqueda.' : 'Todavía no hay solicitudes de traslado.' ?>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table align-middle mb-0 tabla-acciones">
                <thead>
                    <tr><th>Paciente</th><th>Recorrido</th><th>Horarios</th><?php if ($admin): ?><th>Solicitó</th><?php endif; ?><th>Estado</th><th>Ambulancia</th><th class="text-end">Acciones</th></tr>
                </thead>
                <tbody>
                <?php foreach ($traslados as $t):
                    $id = (int) $t['id_traslado'];
                    [$textoEstado, $colorEstado] = ESTADOS_TRASLADO[$t['estado']] ?? [$t['estado'], 'secondary'];
                    $esMio = (int) $t['id_solicitante'] === (int) $u['id_funcionario'];
                    $puedeCambiar = isset(SEGUIMIENTO_TRASLADO[$t['estado']]) && ($admin || $esMio);
                    $puedeCancelar = ($t['estado'] === 'pendiente' && ($admin || $esMio)) || ($t['estado'] === 'asignado' && $admin); ?>
                    <tr>
                        <td>
                            <div class="fw-semibold"><?= h($t['nombre_paciente']) ?></div>
                            <div class="small text-secondary"><?= h(formatear_cedula($t['cedula_paciente'])) ?> · Contaminación: <?= h($t['tipo_contaminacion']) ?></div>
                        </td>
                        <td>
                            <?= h($t['origen']) ?> → <?= h($t['destino']) ?>
                            <div class="small text-secondary">Recibe: <?= h($t['recibe_destino']) ?></div>
                        </td>
                        <td class="text-nowrap small">
                            Salida: <?= h(formatear_fecha($t['fecha_salida'])) ?><br>
                            Llegada: <?= h(formatear_fecha($t['fecha_llegada'])) ?>
                        </td>
                        <?php if ($admin): ?><td><?= h(nombre_visible($t['solicitante'])) ?></td><?php endif; ?>
                        <td>
                            <?php if ($puedeCambiar): ?>
                                <?php ?>
                                <form method="POST" action="<?= h(url('traslados/estado.php')) ?>" class="dropdown">
                                    <?= csrf_campo() ?>
                                    <input type="hidden" name="id" value="<?= $id ?>">
                                    <input type="hidden" name="accion" value="cambiar">
                                    <button type="button" class="badge text-bg-<?= h($colorEstado) ?> border-0 dropdown-toggle menu-estado"
                                            data-bs-toggle="dropdown" aria-expanded="false" title="Cambiar el estado">
                                        <?= h($textoEstado) ?>
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li><h6 class="dropdown-header">Cambiar estado a</h6></li>
                                        <?php foreach (SEGUIMIENTO_TRASLADO as $clave => $_): ?>
                                            <li>
                                                <button type="submit" name="estado" value="<?= h($clave) ?>"
                                                        class="dropdown-item<?= $clave === $t['estado'] ? ' active' : '' ?>"<?= $clave === $t['estado'] ? ' disabled' : '' ?>>
                                                    <?= h($clave === 'asignado' ? 'Ambulancia asignada (todavía no salió)' : ESTADOS_TRASLADO[$clave][0]) ?>
                                                </button>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </form>
                            <?php else: ?>
                                <span class="badge text-bg-<?= h($colorEstado) ?>"><?= h($textoEstado) ?></span>
                            <?php endif; ?>
                            <?php if (!empty($t['motivo'])): ?><div class="small text-secondary">Motivo: <?= h($t['motivo']) ?></div><?php endif; ?>
                        </td>
                        <td>
                            <?php if ($t['ambulancia']): ?>
                                <?= h($t['ambulancia']) ?>
                                <div class="small text-secondary"><?= h((string) $t['matricula']) ?> · <?= h((string) $t['conductor']) ?></div>
                            <?php else: ?><span class="text-secondary">-</span><?php endif; ?>
                        </td>
                        <td class="text-end text-nowrap">
                            <?php if ($admin && $t['estado'] === 'pendiente'): ?>
                                <a class="btn btn-sm btn-success" href="<?= h(url('traslados/asignar.php?id=' . $id)) ?>">Asignar ambulancia</a>
                            <?php endif; ?>
                            <?php if ($admin && $t['estado'] === 'asignado'): ?>
                                <form method="POST" action="<?= h(url('traslados/estado.php')) ?>"
                                      onsubmit="return confirm('¿Quitar la ambulancia? La solicitud vuelve a pendiente.');">
                                    <?= csrf_campo() ?>
                                    <input type="hidden" name="id" value="<?= $id ?>">
                                    <input type="hidden" name="accion" value="desasignar">
                                    <button class="btn btn-sm btn-outline-secondary" type="submit">Quitar ambulancia</button>
                                </form>
                            <?php endif; ?>
                            <?php if ($puedeCancelar): ?>
                                <form method="POST" action="<?= h(url('traslados/estado.php')) ?>"
                                      onsubmit="return confirm('¿Cancelar esta solicitud de traslado?');">
                                    <?= csrf_campo() ?>
                                    <input type="hidden" name="id" value="<?= $id ?>">
                                    <input type="hidden" name="accion" value="cancelar">
                                    <button class="btn btn-sm btn-outline-danger" type="submit">Cancelar</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer d-flex flex-wrap justify-content-between align-items-center gap-2">
            <small class="text-secondary"><?= $total ?> traslado<?= $total === 1 ? '' : 's' ?></small>
            <?= html_paginacion($pagina, $paginas) ?>
        </div>
    <?php endif; ?>
</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.menu-estado').forEach(function (b) {
        new bootstrap.Dropdown(b, { popperConfig: function (def) { return Object.assign({}, def, { strategy: 'fixed' }); } });
    });
});
</script>
<?php pie(); ?>
