<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/traslados.php';

requerir_admin();
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    exigir_post_con_csrf();
    $accion = (string) ($_POST['accion'] ?? '');
    $id = (int) ($_POST['id'] ?? 0);

    if ($accion === 'guardar') {
        $nombre = trim((string) ($_POST['nombre'] ?? ''));
        $cedula = normalizar_cedula((string) ($_POST['cedula'] ?? ''));
        $error = '';
        if ($nombre === '' || mb_strlen($nombre) > 100) {
            $error = 'Ingrese el nombre completo (hasta 100 caracteres).';
        } elseif ($cedula === null) {
            $error = 'La cédula no es válida: tiene que tener 7 u 8 dígitos, por ejemplo 1.234.567-2.';
        } else {
            try {
                if ($id > 0) {
                    $pdo->prepare('UPDATE conductor SET nombre_completo = ?, cedula = ? WHERE id_conductor = ?')->execute([$nombre, $cedula, $id]);
                    avisar('Conductor actualizado.');
                } else {
                    $pdo->prepare('INSERT INTO conductor (nombre_completo, cedula) VALUES (?, ?)')->execute([$nombre, $cedula]);
                    avisar('Conductor registrado. Ahora puede asignarlo a una ambulancia.');
                }
                redirigir('traslados/conductores.php');
            } catch (PDOException $e) {
                if ($e->getCode() === '23000') {
                    $error = 'Ya hay un conductor con esa cédula.';
                } else {
                    error_log('[sigsm] ' . $e->getMessage());
                    $error = 'No se pudo guardar. Intente de nuevo.';
                }
            }
        }
        avisar($error, 'danger');
        redirigir('traslados/conductores.php' . ($id > 0 ? '?id=' . $id : ''));
    }

    if ($accion === 'eliminar') {
        $q = $pdo->prepare('SELECT nombre FROM ambulancia WHERE id_conductor = ?');
        $q->execute([$id]);
        if ($amb = $q->fetchColumn()) {
            avisar('No se puede eliminar: es el conductor de «' . $amb . '». Cambie antes el conductor de esa ambulancia.', 'warning');
        } else {
            $r = $pdo->prepare('DELETE FROM conductor WHERE id_conductor = ?');
            $r->execute([$id]);
            avisar($r->rowCount() > 0 ? 'Conductor eliminado.' : 'El conductor no existe.', $r->rowCount() > 0 ? 'success' : 'warning');
        }
    }
    redirigir('traslados/conductores.php');
}

$conductores = $pdo->query(
    'SELECT c.id_conductor, c.nombre_completo, c.cedula, a.nombre AS ambulancia
       FROM conductor c LEFT JOIN ambulancia a ON a.id_conductor = c.id_conductor ORDER BY c.nombre_completo'
)->fetchAll();

$editar = null;
$idEditar = (int) ($_GET['id'] ?? 0);
foreach ($conductores as $c) {
    if ((int) $c['id_conductor'] === $idEditar) {
        $editar = $c;
    }
}

encabezado('Conductores', 'traslados');
?>
<p class="d-flex justify-content-between">
    <a href="<?= h(url('traslados/ambulancias.php')) ?>">&larr; Volver a ambulancias</a>
</p>
<p class="text-secondary">Los conductores no tienen acceso al gestor: acá solo se guardan sus datos para asignarlos a una ambulancia.</p>

<div class="row g-4">
    <div class="col-12 col-xl-5">
        <div class="card">
            <div class="card-header fw-semibold"><?= $editar ? 'Editar conductor' : 'Registrar conductor' ?></div>
            <div class="card-body">
                <form method="POST" autocomplete="off">
                    <?= csrf_campo() ?>
                    <input type="hidden" name="accion" value="guardar">
                    <input type="hidden" name="id" value="<?= (int) ($editar['id_conductor'] ?? 0) ?>">
                    <div class="mb-3">
                        <label class="form-label" for="nombre">Nombre completo</label>
                        <input class="form-control" id="nombre" name="nombre" maxlength="100" required value="<?= h($editar['nombre_completo'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="cedula">Cédula de identidad</label>
                        <input class="form-control" id="cedula" name="cedula" maxlength="15" required inputmode="numeric" placeholder="1.234.567-2"
                               value="<?= h(!empty($editar['cedula']) ? formatear_cedula($editar['cedula']) : '') ?>">
                    </div>
                    <button class="btn btn-primary" type="submit"><?= $editar ? 'Guardar cambios' : 'Registrar' ?></button>
                    <?php if ($editar): ?><a class="btn btn-outline-secondary" href="<?= h(url('traslados/conductores.php')) ?>">Cancelar</a><?php endif; ?>
                </form>
            </div>
        </div>
    </div>

    <div class="col-12 col-xl-7">
        <div class="card">
            <?php if (!$conductores): ?>
                <div class="card-body text-secondary">Todavía no hay conductores registrados.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table align-middle mb-0 tabla-acciones">
                        <thead><tr><th>Conductor</th><th>Cédula</th><th>Ambulancia</th><th class="text-end">Acciones</th></tr></thead>
                        <tbody>
                        <?php foreach ($conductores as $c): $idC = (int) $c['id_conductor']; ?>
                            <tr>
                                <td class="fw-semibold"><?= h($c['nombre_completo']) ?></td>
                                <td class="text-nowrap"><?= $c['cedula'] ? h(formatear_cedula($c['cedula'])) : '<span class="badge text-bg-warning">Falta</span>' ?></td>
                                <td><?= $c['ambulancia'] ? h($c['ambulancia']) : '<span class="text-secondary">Sin ambulancia</span>' ?></td>
                                <td class="text-end text-nowrap">
                                    <a class="btn btn-sm btn-outline-warning" href="<?= h(url('traslados/conductores.php?id=' . $idC)) ?>">Editar</a>
                                    <form method="POST" onsubmit="return confirm('¿Eliminar a este conductor?');">
                                        <?= csrf_campo() ?>
                                        <input type="hidden" name="accion" value="eliminar">
                                        <input type="hidden" name="id" value="<?= $idC ?>">
                                        <button class="btn btn-sm btn-outline-danger" type="submit">Eliminar</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php pie(); ?>
