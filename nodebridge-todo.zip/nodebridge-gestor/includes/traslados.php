<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/ambulancias.php';

const ESTADOS_TRASLADO = [
    'pendiente'     => ['Pendiente', 'warning'],
    'asignado'      => ['Ambulancia asignada', 'primary'],
    'en_camino'     => ['En camino', 'info'],
    'llego_destino' => ['Llegó al destino', 'info'],
    'volviendo'     => ['Volviendo', 'secondary'],
    'finalizado'    => ['Finalizado', 'success'],
    'cancelado'     => ['Cancelado', 'secondary'],
    'rechazado'     => ['Rechazado', 'danger'],
];

const ESTADOS_TRASLADO_ACTIVOS = ['asignado', 'en_camino', 'llego_destino', 'volviendo'];

const SEGUIMIENTO_TRASLADO = [
    'asignado'      => 'disponible',
    'en_camino'     => 'en_camino',
    'llego_destino' => 'llego_destino',
    'volviendo'     => 'volviendo',
    'finalizado'    => 'disponible',
];

function fecha_desde_formulario(string $valor): ?string
{
    $f = DateTime::createFromFormat('Y-m-d\TH:i', trim($valor));
    $errores = DateTime::getLastErrors();
    if ($f === false || ($errores && ($errores['warning_count'] > 0 || $errores['error_count'] > 0))) {
        return null;
    }
    return $f->format('Y-m-d H:i:s');
}

function fecha_para_formulario(?string $fecha): string
{
    $t = $fecha ? strtotime($fecha) : false;
    return $t ? date('Y-m-d\TH:i', $t) : '';
}

function traslados_pendientes(): int
{
    try {
        return (int) db()->query("SELECT COUNT(*) FROM traslado WHERE estado = 'pendiente'")->fetchColumn();
    } catch (PDOException $e) {
        return 0;
    }
}

function ambulancias_asignables(): array
{
    $marcas = implode(',', array_fill(0, count(ESTADOS_TRASLADO_ACTIVOS), '?'));
    $st = db()->prepare(
        "SELECT a.id_ambulancia, a.nombre, a.matricula, c.nombre_completo AS conductor
           FROM ambulancia a
           LEFT JOIN conductor c ON c.id_conductor = a.id_conductor
          WHERE a.estado = 'disponible'
            AND NOT EXISTS (SELECT 1 FROM traslado t WHERE t.id_ambulancia = a.id_ambulancia AND t.estado IN ($marcas))
          ORDER BY a.nombre"
    );
    $st->execute(ESTADOS_TRASLADO_ACTIVOS);
    return $st->fetchAll();
}
