<?php
declare(strict_types=1);

const ESTADOS_AMBULANCIA = [
    'disponible'     => ['Disponible', 'success'],
    'en_camino'      => ['En camino', 'warning'],
    'llego_destino'  => ['Llegó al destino', 'primary'],
    'volviendo'      => ['Volviendo', 'info'],
    'fuera_servicio' => ['Fuera de servicio', 'secondary'],
];

function normalizar_matricula(string $texto): ?string
{
    $m = strtoupper(trim(preg_replace('/\s+/', ' ', $texto) ?? ''));
    return preg_match('/^[A-Z0-9][A-Z0-9 \-]{3,9}$/', $m) ? $m : null;
}
