<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

redirigir(usuario_actual() ? 'panel.php' : 'login.php');
