<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/encuestas.php';
require_once __DIR__ . '/../includes/portal.php';

requerir_admin();
$pdo = db();

$q = trim((string) ($_GET['q'] ?? ''));
$sectorSel = (int) ($_GET['sector'] ?? 0);

$donde = [];
$params = [];
if ($q !== '') {
    $donde[] = 'e.titulo_encuesta LIKE ?';
    $params[] = '%' . addcslashes($q, '%_\\') . '%';
}
if ($sectorSel > 0) {
    $donde[] = 'e.id_sector = ?';
    $params[] = $sectorSel;
}
$sqlDonde = $donde ? 'WHERE ' . implode(' AND ', $donde) : '';

$st = $pdo->prepare("SELECT COUNT(*) FROM encuesta e $sqlDonde");
$st->execute($params);
$total = (int) $st->fetchColumn();

$porPagina = 15;
[$pagina, $paginas, $desde] = paginar($total, $porPagina);

$st = $pdo->prepare(
    "SELECT e.id_encuesta, e.titulo_encuesta, e.activa, e.estado_portal, e.fecha_modificacion,
            s.nombre_sector,
            (SELECT COUNT(*) FROM pregunta p WHERE p.id_encuesta = e.id_encuesta) AS cantidad_preguntas
       FROM encuesta e
       JOIN sector s ON s.id_sector = e.id_sector
       $sqlDonde
      ORDER BY e.fecha_modificacion DESC, e.id_encuesta DESC
      LIMIT $porPagina OFFSET $desde"
);
$st->execute($params);
$encuestas = $st->fetchAll();

$sectores = listar_sectores();
$hayFiltros = ($q !== '' || $sectorSel > 0);

$hayEncuestas = $encuestas ? true : (bool) $pdo->query('SELECT 1 FROM encuesta LIMIT 1')->fetchColumn();
$pendientesPortal = (int) $pdo->query('SELECT COUNT(*) FROM encuesta WHERE ' . SQL_ENCUESTAS_PENDIENTES_PORTAL)->fetchColumn();

encabezado('Encuestas', 'encuestas');
?>
<p class="text-secondary">
    Las encuestas <strong>activas</strong> se publican en el portal informativo, donde los pacientes las responden.
    Las respuestas llegan a la sección «Respuestas».
</p>
<?php if (!portal_configurado()): ?>
    <div class="alert alert-warning"><?= h(MSG_PORTAL_SIN_CONFIGURAR) ?> Las encuestas se guardan, pero no se publican en el portal.</div>
<?php endif; ?>

<div class="d-flex flex-wrap gap-2 justify-content-between align-items-start mb-3">
    <form method="GET" class="row g-2 flex-grow-1" style="max-width: 760px;">
        <div class="col-12 col-md-5">
            <input type="search" class="form-control" name="q" placeholder="Buscar por nombre de la encuesta..."
                   value="<?= h($q) ?>" aria-label="Buscar por nombre de la encuesta">
        </div>
        <div class="col-12 col-md-4">
            <select class="form-select" name="sector" aria-label="Sector">
                <option value="0">Todos los sectores</option>
                <?php foreach ($sectores as $s): ?>
                    <option value="<?= (int) $s['id_sector'] ?>"<?= $sectorSel === (int) $s['id_sector'] ? ' selected' : '' ?>>
                        <?= h($s['nombre_sector']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-6 col-md-2 d-grid">
            <button class="btn btn-primary" type="submit">Buscar</button>
        </div>
        <?php if ($hayFiltros): ?>
            <div class="col-6 col-md-1 d-grid">
                <a class="btn btn-outline-secondary" href="<?= h(url('encuestas/index.php')) ?>" title="Quitar filtros">Limpiar</a>
            </div>
        <?php endif; ?>
    </form>

    <div class="d-flex flex-wrap gap-2">
        <?php if ($pendientesPortal > 0): ?>
            <form method="POST" action="<?= h(url('encuestas/publicar.php')) ?>">
                <?= csrf_campo() ?>
                <input type="hidden" name="accion" value="pendientes">
                <button class="btn btn-outline-primary" type="submit">Actualizar el portal (<?= $pendientesPortal ?>)</button>
            </form>
        <?php endif; ?>
        <a class="btn btn-success" href="<?= h(url('encuestas/formulario.php')) ?>">Nueva encuesta</a>
    </div>
</div>

<div class="card">
    <?php if (!$encuestas): ?>
        <div class="card-body text-secondary">
            <?= $hayEncuestas ? 'No se encontraron encuestas con esa búsqueda.' : 'Todavía no hay encuestas creadas.' ?>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table align-middle mb-0 tabla-acciones">
                <thead>
                    <tr>
                        <th>Encuesta</th><th>Sector</th><th>Preguntas</th><th>Estado</th><th>Portal</th><th>Modificada</th>
                        <th class="text-end">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($encuestas as $e): $id = (int) $e['id_encuesta']; ?>
                    <tr>
                        <td><?= h($e['titulo_encuesta']) ?></td>
                        <td><?= h($e['nombre_sector']) ?></td>
                        <td><?= (int) $e['cantidad_preguntas'] ?></td>
                        <td>
                            <?= $e['activa']
                                ? '<span class="badge text-bg-success">Activa</span>'
                                : '<span class="badge text-bg-secondary">Inactiva</span>' ?>
                        </td>
                        <td>
                            <?php [$textoPortal, $colorPortal] = etiqueta_portal_encuesta((int) $e['activa'], (int) $e['estado_portal']); ?>
                            <span class="badge text-bg-<?= h($colorPortal) ?>"><?= h($textoPortal) ?></span>
                        </td>
                        <td class="text-nowrap"><?= h(formatear_fecha($e['fecha_modificacion'])) ?></td>
                        <td class="text-end text-nowrap">
                            <?php if ($colorPortal === 'warning'): ?>
                                <form method="POST" action="<?= h(url('encuestas/publicar.php')) ?>">
                                    <?= csrf_campo() ?>
                                    <input type="hidden" name="accion" value="una">
                                    <input type="hidden" name="id" value="<?= $id ?>">
                                    <button class="btn btn-sm btn-outline-primary" type="submit">Publicar</button>
                                </form>
                            <?php endif; ?>
                            <form method="POST" action="<?= h(url('encuestas/estado.php')) ?>"
                                  <?= $e['activa'] ? 'onsubmit="return confirm(\'¿Desactivar esta encuesta? Dejará de mostrarse a los pacientes.\');"' : '' ?>>
                                <?= csrf_campo() ?>
                                <input type="hidden" name="id" value="<?= $id ?>">
                                <input type="hidden" name="activa" value="<?= $e['activa'] ? 0 : 1 ?>">
                                <button class="btn btn-sm btn-outline-<?= $e['activa'] ? 'secondary' : 'success' ?>" type="submit">
                                    <?= $e['activa'] ? 'Desactivar' : 'Activar' ?>
                                </button>
                            </form>
                            <a class="btn btn-sm btn-outline-warning"
                               href="<?= h(url('encuestas/formulario.php?id=' . $id)) ?>">Editar</a>
                            <form method="POST" action="<?= h(url('encuestas/eliminar.php')) ?>"
                                  onsubmit="return confirm('¿Eliminar esta encuesta con todas sus preguntas? Esta acción no se puede deshacer.');">
                                <?= csrf_campo() ?>
                                <input type="hidden" name="id" value="<?= $id ?>">
                                <button class="btn btn-sm btn-outline-danger" type="submit">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer d-flex flex-wrap justify-content-between align-items-center gap-2">
            <small class="text-secondary"><?= $total ?> encuesta<?= $total === 1 ? '' : 's' ?></small>
            <?= html_paginacion($pagina, $paginas) ?>
        </div>
    <?php endif; ?>
</div>
<?php pie(); ?>
